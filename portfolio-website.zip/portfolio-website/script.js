// Add interactive features here if needed
console.log("Website loaded");